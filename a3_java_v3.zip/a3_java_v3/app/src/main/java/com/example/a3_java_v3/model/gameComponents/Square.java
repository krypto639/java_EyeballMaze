package com.example.a3_java_v3.model.gameComponents;

import com.example.a3_java_v3.model.gameEnums.Color;
import com.example.a3_java_v3.model.gameEnums.Shape;

public abstract class Square {
    protected Shape shape;
    protected Color color;

    public Square(Color color, Shape shape) {
        this.color = color;
        this.shape = shape;
    }
}