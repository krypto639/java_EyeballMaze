package com.example.a3_java_v3.model.Interfaces;

import com.example.a3_java_v3.model.gameEnums.Direction;

public interface IEyeballHolder {
    public void addEyeball(int column, int row, Direction direction);

    public int getEyeballRow();

    public int getEyeballColumn();

    public Direction getEyeballDirection();

    public int setEyeballRow(int row);

    public int setEyeballColumn(int column);

    public Direction setEyeballDirection(Direction direction);
}
