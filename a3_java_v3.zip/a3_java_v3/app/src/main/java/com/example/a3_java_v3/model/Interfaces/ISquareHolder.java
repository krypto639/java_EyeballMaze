package com.example.a3_java_v3.model.Interfaces;


import com.example.a3_java_v3.model.gameComponents.Square;
import com.example.a3_java_v3.model.gameEnums.Color;
import com.example.a3_java_v3.model.gameEnums.Shape;

public interface ISquareHolder {
    public void addSquare(Square square, int column, int row);

    public Color getColorAt(int column, int row);

    public Shape getShapeAt(int column, int row);

}
