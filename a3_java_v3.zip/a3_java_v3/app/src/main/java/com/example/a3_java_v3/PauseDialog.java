package com.example.a3_java_v3;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Chronometer;

import androidx.appcompat.app.AppCompatDialogFragment;

public class PauseDialog extends AppCompatDialogFragment {
    private Chronometer chronometer;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        String[] dialog_options = getActivity().getResources().getStringArray(R.array.pause_dialog_options);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Information")
                .setItems(dialog_options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
//                        Toast.makeText(getActivity(), "You choose "+dialog_options[i],Toast.LENGTH_SHORT).show();
                        if (i == 0) {
                            //Resume
//                            Toast.makeText(getActivity(), "You choose " + dialog_options[i], Toast.LENGTH_SHORT).show();
                            ((MainActivity) getActivity()).toggleChronometerOn(null);
                        } else if (i == 1) {
                            //Save and Exit
                            ((MainActivity) getActivity()).setContentView(R.layout.activity_main);
                            ((MainActivity) getActivity()).saveData();
                            ((MainActivity) getActivity()).confirmSaveToLoad(null);
//                            Toast.makeText(getActivity(), "Jesus Christ", Toast.LENGTH_SHORT).show();

                        } else if (i == 2) {
                            //Exit
                            ((MainActivity) getActivity()).setContentView(R.layout.activity_main);
                            ((MainActivity) getActivity()).confirmSaveToLoad(null);
//                            Toast.makeText(getActivity(), "Godzilla", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

//                .setMessage("This is a dialog")
//                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//
//                    }
//                });

        return builder.create();

    }
}
