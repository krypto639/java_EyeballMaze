package com.example.a3_java_v3.model.Interfaces;

import com.example.a3_java_v3.model.gameEnums.Message;

public interface IMoving {
    public boolean canMoveTo(int destinationColumn, int destinationRow);

    public Message MessageIfMovingTo(int destinationColumn, int destinationRow);

    public boolean isDirectionOK(int destinationColumn, int destinationRow);

    public Message checkDirectionMessage(int destinationColumn, int destinationRow);

    public boolean hasBlankFreePathTo(int destinationColumn, int destinationRow);

    public Message checkMessageForBlankOnPathTo(int destinationColumn, int destinationRow);

    public void moveTo(int destinationColumn, int destinationRow);
}
