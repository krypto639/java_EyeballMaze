package com.example.a3_java_v3;

import android.content.Context;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import androidx.annotation.RequiresApi;

import com.example.a3_java_v3.model.gameComponents.Game;
import com.example.a3_java_v3.model.gameEnums.Direction;
import com.example.a3_java_v3.MainActivity;

/**
 * Created by tutlane on 24-08-2017.
 */
public class ImageAdapter extends BaseAdapter {
    private Context mContext;
    int[] gameSquares;
    Game game;
    private int imageViewCount = 0;

    public ImageAdapter(Context c, int[] squares, Game game) {

        this.mContext = c;
        this.gameSquares = squares;
        this.game = game;
    }

    public int getCount() {
        return gameSquares.length;
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return 0;
    }




    // create a new ImageView for each item referenced by the Adapter
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView = new ImageView(mContext);
        imageView.setId(imageViewCount);
        ++imageViewCount;
        imageView.setLayoutParams(new GridView.LayoutParams(200, 200));

        //inputting game values
        int gameWidth = game.getLevelWidth();
        int y = position / gameWidth;
        int x = position % gameWidth;


        if (game.hasGoalAt(x, y)) {
            imageView.setBackgroundResource(R.drawable.goal);
        }

        if (game.getEyeballRow() == y && game.getEyeballColumn() == x) {
            Direction direction = game.getEyeballDirection();
            if (direction == Direction.UP) {
                imageView.setBackgroundResource(R.drawable.eye_facing_up);
            } else if (direction == Direction.DOWN) {
                imageView.setBackgroundResource(R.drawable.eye_facing_down);
            } else if (direction == Direction.LEFT) {
                imageView.setBackgroundResource(R.drawable.eye_facing_left);
            }
            if (direction == Direction.RIGHT) {
                imageView.setBackgroundResource(R.drawable.eye_facing_right);
            }
        }


//        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
//        imageView.setPadding(8, 8, 8, 8);
        imageView.setImageResource(gameSquares[position]);
        return imageView;
    }
    // Add all our images to arraylist
//    public Integer[] gameSquares = {
//            R.drawable._0x, R.drawable._0x, R.drawable._flower_red, R.drawable._0x, R.drawable._cross_blue, R.drawable._flower_yellow, R.drawable._diamond_yellow, R.drawable._cross_green,
//            R.drawable._flower_green, R.drawable._star_red, R.drawable._star_green, R.drawable._diamond_yellow, R.drawable._flower_red, R.drawable._flower_blue, R.drawable._star_red, R.drawable._flower_green,
//            R.drawable._star_blue, R.drawable._diamond_red, R.drawable._flower_blue, R.drawable._diamond_blue, R.drawable._0x, R.drawable._diamond_blue, R.drawable._0x,R.drawable._0x
//    };
}