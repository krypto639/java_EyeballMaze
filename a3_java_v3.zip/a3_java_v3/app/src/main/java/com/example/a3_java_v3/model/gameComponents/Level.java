package com.example.a3_java_v3.model.gameComponents;

import com.example.a3_java_v3.model.Interfaces.IEyeballHolder;
import com.example.a3_java_v3.model.Interfaces.IGoalHolder;
import com.example.a3_java_v3.model.Interfaces.ISquareHolder;
import com.example.a3_java_v3.model.gameEnums.Color;
import com.example.a3_java_v3.model.gameEnums.Direction;
import com.example.a3_java_v3.model.gameEnums.Message;
import com.example.a3_java_v3.model.gameEnums.Shape;

import java.util.ArrayList;
import java.util.List;

import static com.example.a3_java_v3.model.gameEnums.Direction.DOWN;
import static com.example.a3_java_v3.model.gameEnums.Direction.LEFT;
import static com.example.a3_java_v3.model.gameEnums.Direction.RIGHT;
import static com.example.a3_java_v3.model.gameEnums.Direction.UP;

public class Level implements IEyeballHolder, IGoalHolder, ISquareHolder {
    public int height;
    public int width;
    protected Square[][] allLevelSquares;
    protected List<Goal> allLevelGoals = new ArrayList<Goal>();
    protected int goalsCompleted;
    protected Eyeball gameCharacter;
    protected Message moveMessage;

    public Level(int width, int height) {
        this.height = height;
        this.width = width;
        this.allLevelSquares = new Square[width][height];
        this.goalsCompleted = 0;
    }

//	@Override
//	public int getLevelWidth() {
//		return this.width;
//	}
//
//	@Override
//	public int getLevelHeight() {
//		return this.height;
//	}

    //	SHAPES
    @Override
    public void addSquare(Square square, int column, int row) {
        if (row > this.height || column > this.width) {
            throw new IllegalArgumentException();
        } else {
            this.allLevelSquares[column][row] = square;
        }
    }

    @Override
    public Color getColorAt(int column, int row) {
        return this.allLevelSquares[column][row].color;
    }

    @Override
    public Shape getShapeAt(int column, int row) {
        return this.allLevelSquares[column][row].shape;
    }

//	@Override
//	public void addLevel(int height, int width) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void setLevel(int levelNumber) {
////		// TODO Auto-generated method stub
////		
////	}
//
//	@Override
//	public int getLevelCount() {
//		// TODO Auto-generated method stub
//		return 0;
//	}

    //	GOAL SETUP AND VALIDATION
    @Override
    public void addGoal(int column, int row) {
        if (row > this.height || column > this.width) {
            throw new IllegalArgumentException();
        } else {
            Goal goal = new Goal(column, row);
            this.allLevelGoals.add(goal);
        }

    }

    @Override
    public int getGoalCount() {
        return this.allLevelGoals.size();
    }

    @Override
    public boolean hasGoalAt(int targetColumn, int targetRow) {
        boolean goalLocated = false;

        for (int i = 0; i < this.allLevelGoals.size(); i++) {
            int existingGoalColumn = this.allLevelGoals.get(i).column;
            int existingGoalRow = this.allLevelGoals.get(i).row;
            if (targetColumn == existingGoalColumn && targetRow == existingGoalRow) {
                goalLocated = true;
                break;
            }
        }
        return goalLocated;
    }

    @Override
    public int getCompletedGoalCount() {
        return this.goalsCompleted;
    }

    @Override
    public void restoreGoal(int columnLastAt, int rowLastAt) {
        Goal goal = new Goal(columnLastAt, rowLastAt);
        this.allLevelGoals.add(goal);
        this.goalsCompleted--;
        this.getGoalCount();
    }

    //	EYEBALL METHODS AND SETUP
    @Override
    public void addEyeball(int column, int row, Direction direction) {
        if (row > this.height || column > this.width) {
            throw new IllegalArgumentException();
        } else {
            Eyeball eyeball = new Eyeball(column, row, direction);
            this.gameCharacter = eyeball;
        }
    }

    @Override
    public int getEyeballRow() {
        return this.gameCharacter.getRow();
    }

    @Override
    public int getEyeballColumn() {
        return this.gameCharacter.getColumn();
    }

    @Override
    public Direction getEyeballDirection() {
        return this.gameCharacter.getDirection();
    }

    @Override
    public int setEyeballRow(int row) {
        this.gameCharacter.row = row;
        return this.getEyeballRow();
    }

    @Override
    public int setEyeballColumn(int column) {
        this.gameCharacter.column = column;
        return this.getEyeballColumn();
    }

    @Override
    public Direction setEyeballDirection(Direction direction) {
        this.gameCharacter.direction = direction;
        return this.getEyeballDirection();
    }

    //	MOVEMENT METHODS
    public boolean canMoveTo(int column, int row) {
        //currentPosition
        Shape eyeCurrentShape = this.getShapeAt(this.gameCharacter.getColumn(), this.gameCharacter.getRow());
        Color eyeCurrentColor = this.getColorAt(this.gameCharacter.getColumn(), this.gameCharacter.getRow());

        //destinationPosition
        Shape destinationShape = this.getShapeAt(column, row);
        Color destinationColor = this.getColorAt(column, row);
        boolean validLocation = false;

        if (
                row < this.height
                        && column < this.width
                        && this.isDirectionOK(column, row) == true
//			&& this.hasBlankFreePathTo(row, column)==true
        ) {
            if (eyeCurrentShape == destinationShape || eyeCurrentColor == destinationColor) {
                validLocation = true;

            }
        }
        return validLocation;
    }

    public Message MessageIfMovingTo(int column, int row) {
        if (this.canMoveTo(column, row) == true) {
            return Message.OK;
        } else {
            return Message.DIFFERENT_SHAPE_OR_COLOR;
        }

    }

    public boolean isDirectionOK(int column, int row) {
        Direction eyeDirectionFacing = this.getEyeballDirection();
        int eyeRow = this.getEyeballRow();
        int eyeColumn = this.getEyeballColumn();
        boolean isDirectionOk;

//        boolean isDirectionOk = switch (eyeDirectionFacing) {
//            case UP -> row <= eyeRow;
//            case DOWN -> row >= eyeRow;
//            case LEFT -> column <= eyeColumn;
//            case RIGHT -> column >= eyeColumn;
//            default -> false;
//        };
        if (eyeDirectionFacing == UP) {
            isDirectionOk = row <= eyeRow;
        } else if (eyeDirectionFacing == DOWN) {
            isDirectionOk = row >= eyeRow;
        } else if (eyeDirectionFacing == LEFT) {
            isDirectionOk = column <= eyeColumn;
        } else if (eyeDirectionFacing == RIGHT) {
            isDirectionOk = column >= eyeColumn;
        } else {
            isDirectionOk = false;
        }

        if (row == eyeRow || column == eyeColumn) {
            return isDirectionOk;
        } else {
            return false;
        }

    }

    public Message checkMessageForBlankOnPathTo(int targetColumn, int targetRow) {
        if (this.hasBlankFreePathTo(targetColumn, targetRow) == false) {
            return Message.MOVING_OVER_BLANK;
        }
        return Message.OK;
    }

    public Message checkDirectionMessage(int column, int row) {
        if (!this.isDirectionOK(column, row)) {
            if (row != this.getEyeballRow() && column != this.getEyeballColumn()) {
                return Message.MOVING_DIAGONALLY;
            } else {
                return Message.BACKWARDS_MOVE;
            }
        }
        return Message.OK;

    }

    public void moveTo(int targetColumn, int targetRow) {
        int eyeColumn = this.getEyeballColumn();
        int eyeRow = this.getEyeballRow();
        if (this.canMoveTo(targetColumn, targetRow)) {
            //moving up
            if (eyeRow > targetRow && eyeColumn == targetColumn) {
                this.gameCharacter.column = targetColumn;
                this.gameCharacter.row = targetRow;
                this.gameCharacter.direction = UP;
            }
            //moving down
            if (eyeRow < targetRow && eyeColumn == targetColumn) {
                this.gameCharacter.column = targetColumn;
                this.gameCharacter.row = targetRow;
                this.gameCharacter.direction = Direction.DOWN;
            }
            //moving left
            if (eyeColumn > targetColumn && eyeRow == targetRow) {
                this.gameCharacter.column = targetColumn;
                this.gameCharacter.row = targetRow;
                this.gameCharacter.direction = Direction.LEFT;
            }
            //moving right
            if (eyeColumn < targetColumn && eyeRow == targetRow) {
                this.gameCharacter.column = targetColumn;
                this.gameCharacter.row = targetRow;
                this.gameCharacter.direction = Direction.RIGHT;
            }

            for (int i = 0; i < this.allLevelGoals.size(); i++) {
                int existingGoalColumn = this.allLevelGoals.get(i).column;
                int existingGoalRow = this.allLevelGoals.get(i).row;
                if (targetColumn == existingGoalColumn && targetRow == existingGoalRow) {
                    this.allLevelGoals.remove(i);
                    this.goalsCompleted++;
                }
            }

        }
    }

    public boolean hasBlankFreePathTo(int targetColumn, int targetRow) {
        int eyeColumn = this.getEyeballColumn();
        int eyeRow = this.getEyeballRow();
        boolean noBlankInPathMoving = true;

        //moving up
        if (eyeRow > targetRow && eyeColumn == targetColumn) {
            for (int x = eyeRow; x >= targetRow; x--) {
                if (this.getShapeAt(x, targetColumn) == Shape.BLANK) {
                    noBlankInPathMoving = false;
                }
            }
        }
//		//moving down
        if (eyeRow < targetRow && eyeColumn == targetColumn) {
            for (int x = eyeRow; x <= targetRow; x++) {

                if (this.getShapeAt(x, targetColumn) == Shape.BLANK) {
                    noBlankInPathMoving = false;
                }
            }
        }

        //moving left
        if (eyeColumn > targetColumn && eyeRow == targetRow) {
            for (int y = eyeColumn; y >= targetColumn; y--) {
                if (this.getShapeAt(targetRow, y) == Shape.BLANK) {
                    noBlankInPathMoving = false;
                }
            }
        }

        //moving right
        if (eyeColumn < targetColumn && eyeRow == targetRow) {
            for (int y = eyeColumn; y <= targetColumn; y++) {
                if (this.getShapeAt(targetRow, y) == Shape.BLANK) {
                    noBlankInPathMoving = false;
                }
            }
        }
        return noBlankInPathMoving;
    }

}
