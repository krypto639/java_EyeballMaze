package com.example.a3_java_v3.model.gameComponents;

import com.example.a3_java_v3.model.gameEnums.Color;
import com.example.a3_java_v3.model.gameEnums.Shape;

public class BlankSquare extends Square {
    public BlankSquare() {
        super(Color.BLANK, Shape.BLANK);
    }
}
