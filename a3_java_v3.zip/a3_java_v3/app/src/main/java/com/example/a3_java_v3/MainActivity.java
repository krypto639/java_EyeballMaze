package com.example.a3_java_v3;


import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.a3_java_v3.model.gameComponents.BlankSquare;
import com.example.a3_java_v3.model.gameComponents.Eyeball;
import com.example.a3_java_v3.model.Interfaces.IEyeballHolder;
import com.example.a3_java_v3.model.gameComponents.Game;
import com.example.a3_java_v3.model.gameComponents.Level;
import com.example.a3_java_v3.model.gameComponents.PlayableSquare;
import com.example.a3_java_v3.model.gameComponents.Square;
import com.example.a3_java_v3.model.gameEnums.Color;
import com.example.a3_java_v3.model.gameEnums.Direction;
import com.example.a3_java_v3.model.gameEnums.Message;
import com.example.a3_java_v3.model.gameEnums.Shape;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    //GameData
    private Game OriginalGame = new Game();
    private List<int[]> originalGameImages = new ArrayList<int[]>();
    private int[] currentLevelsImages;
    private List<int[]> currentLevelImageCollection;

    //GameData-OutputDisplay
    private GridView board;
    private Boolean allGoalsCompleted;
    private int goalsCompleted;
    private int goalsTotal;
    private int levelNum;

    //GameFunctionality-timer
    private Chronometer chronometer;
    private String timeCompletedLevel;
    private boolean running;
    private long pauseOffSet;

    //GameFunctionality-audio, moves
    private boolean audioOn;
    private int moveCount;

    //undo
    private Boolean playerHasMoved = false;
    private int gameWidth;
    private Game gamePlaying;
    private int[] gameSquaresImagesOriginal;
    private List<Eyeball> locationsMovedTo = new ArrayList<Eyeball>();
    //Save
    private boolean savedGameToLoad = false;
    public static final String SHARED_PREFS = "sharedPrefs";
//    private List<Game> gameSaving = new ArrayList<Game>();
//   public static final String TEXT = "text";
    //LoadedData
    private boolean save_data;
    private boolean save_loaded = false;
    private int moveCount_data;
//    private int goalsCompleted_Data;
//    private int getGoalsCompleted_Data;
    private long timer_data;
    private long timerPauseOffSet_data;
    private int levelNum_data;
    private List<int[]> currentLevelImageCollection_data = null;
    private List<Eyeball> locationsMovedTo_data = null;
    //
    private boolean savedGameWon;
    private int loadCount = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createAllLevels(OriginalGame, originalGameImages);
        loadData();
        confirmSaveToLoad(null);

        Button LevelBtn_1 = (Button) findViewById(R.id.Lv1Button);
        save_loaded = false;
        LevelBtn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OriginalGame.setLevel(0);
                levelNum = 1;
//                gamePlaying = new Game();
//                currentLevelImageCollection = new ArrayList<int[]>();
//                createLevel1(gamePlaying, currentLevelImageCollection);
//                currentLevelsImages = currentLevelImageCollection.get(0);
//                gameWidth = OriginalGame.getLevelWidth();
                //duplicating game with level set to store all movements and updates
                    //while maintaining an unedited version for referencing
                displayGame(null);

            }
        });

    }
    //////////////////////////[ Game Output ]////////////////////////////////////

    //switch from menu to displaying game ui and level
    public void displayGame(View view) {
//        loadData();
        setContentView(R.layout.game_display);
        chronometer = findViewById(R.id.TimerDisplay);
        chronometer.setFormat("Time: %s");
        if(save_loaded){
            chronometer.setBase(timer_data-timerPauseOffSet_data);
        }else{
            chronometer.setBase(SystemClock.elapsedRealtime());
        }
        chronometer.start();
        running = true;
        audioOn = true;
        allGoalsCompleted = false;
        timeCompletedLevel = "";
//        if(save_loaded){
//            currentLevelsImages = currentLevelImageCollection.get(0);
//            outputLevel(currentLevelsImages, gamePlaying);
//        }
//        else{
            gamePlaying = new Game();
            if(save_loaded && currentLevelImageCollection_data != null){
                currentLevelImageCollection = currentLevelImageCollection_data;
            }else{
                currentLevelImageCollection = new ArrayList<int[]>();
            }
            createLevel1(gamePlaying, currentLevelImageCollection);
            currentLevelsImages = currentLevelImageCollection.get(0);
            outputLevel(currentLevelsImages, gamePlaying);
//        }

    }

    //Make visible section for loading an existing level if exists
    public void confirmSaveToLoad(View view) {
        if(savedGameWon){
            save_loaded = false;
            this.getSharedPreferences(SHARED_PREFS, MODE_PRIVATE).edit().clear().commit();
            savedGameWon=false;
        }
        loadData();
//        savedGameToLoad = save_data;
        TextView loadGameMsgText = findViewById(R.id.LoadGameMsg);
        ImageButton loadGameBtn = findViewById(R.id.LoadButton);
        ImageButton deleteGameBtn = findViewById(R.id.deleteButton);
        if (!savedGameToLoad || savedGameWon) {
            loadGameMsgText.setVisibility(View.INVISIBLE);
            loadGameBtn.setVisibility(View.INVISIBLE);
            deleteGameBtn.setVisibility(View.INVISIBLE);
        } else if(savedGameToLoad) {
            loadGameMsgText.setVisibility(View.VISIBLE);
            loadGameBtn.setVisibility(View.VISIBLE);
            deleteGameBtn.setVisibility(View.VISIBLE);

        }
    }

    //run all the level data
    public void createAllLevels(Game game, List<int[]> gameLevelImages){
        createLevel1(game, gameLevelImages);
    }

    //create level 1
    public void createLevel1(Game game, List<int[]> gameLevelImages){
        game.addLevel(4, 6);
        game.addGoal(2, 0);
        // height then width?
        //this one somehow width then height?
        game.addEyeball(1, 5, Direction.UP);
        //Grid Row 1
        game.addSquare(new BlankSquare(), 0, 0);
        game.addSquare(new BlankSquare(), 1, 0);
        game.addSquare(new PlayableSquare(Color.RED, Shape.FLOWER), 2, 0);
        game.addSquare(new BlankSquare(), 3, 0);

        //Grid Row 2
        game.addSquare(new PlayableSquare(Color.BLUE, Shape.CROSS), 0, 1);
        game.addSquare(new PlayableSquare(Color.YELLOW, Shape.FLOWER), 1, 1);
        game.addSquare(new PlayableSquare(Color.YELLOW, Shape.DIAMOND), 2, 1);
        game.addSquare(new PlayableSquare(Color.GREEN, Shape.CROSS), 3, 1);

        //Grid Row 3
        game.addSquare(new PlayableSquare(Color.GREEN, Shape.FLOWER), 0, 2);
        game.addSquare(new PlayableSquare(Color.RED, Shape.STAR), 1, 2);
        game.addSquare(new PlayableSquare(Color.GREEN, Shape.STAR), 2, 2);
        game.addSquare(new PlayableSquare(Color.YELLOW, Shape.DIAMOND), 3, 2);

        //Grid Row 4
        game.addSquare(new PlayableSquare(Color.RED, Shape.FLOWER), 0, 3);
        game.addSquare(new PlayableSquare(Color.BLUE, Shape.FLOWER), 1, 3);
        game.addSquare(new PlayableSquare(Color.RED, Shape.STAR), 2, 3);
        game.addSquare(new PlayableSquare(Color.GREEN, Shape.FLOWER), 3, 3);

        //Grid Row 5
        game.addSquare(new PlayableSquare(Color.BLUE, Shape.STAR), 0, 4);
        game.addSquare(new PlayableSquare(Color.RED, Shape.DIAMOND), 1, 4);
        game.addSquare(new PlayableSquare(Color.BLUE, Shape.FLOWER), 2, 4);
        game.addSquare(new PlayableSquare(Color.BLUE, Shape.DIAMOND), 3, 4);

        //Grid Row 6
        game.addSquare(new BlankSquare(), 0, 5);
        game.addSquare(new PlayableSquare(Color.BLUE, Shape.DIAMOND), 1, 5);
        game.addSquare(new BlankSquare(), 2, 5);
        game.addSquare(new BlankSquare(), 3, 5);

        int gameSquares[] = {R.drawable._0x, R.drawable._0x, R.drawable._flower_red, R.drawable._0x,
                R.drawable._cross_blue, R.drawable._flower_yellow, R.drawable._diamond_yellow, R.drawable._cross_green,
                R.drawable._flower_green, R.drawable._star_red, R.drawable._star_green, R.drawable._diamond_yellow,
                R.drawable._flower_red, R.drawable._flower_blue, R.drawable._star_red, R.drawable._flower_green,
                R.drawable._star_blue, R.drawable._diamond_red, R.drawable._flower_blue, R.drawable._diamond_blue,
                R.drawable._0x, R.drawable._diamond_blue, R.drawable._0x, R.drawable._0x
        };

        gameLevelImages.add(gameSquares);
    }

    //from click event listener set level and images needed and output in the board
    public void outputLevel(int[] levelImageList, Game gameUsing){
        Game game = gamePlaying;
        TextView moveDisplay = findViewById(R.id.movesDisplay);
        TextView levelTitle = findViewById(R.id.levelTitle);
        levelTitle.setText("Level "+levelNum);
        gameWidth = game.getLevelWidth();
        if(save_loaded){
            moveCount = moveCount_data;
        }else{
            moveCount = 0;
        }
        goalsTotal = game.getGoalCount();
        moveDisplay.setText("Moves: " + moveCount);
        goalsCompleted = game.getCompletedGoalCount();
        TextView goalDisplay = findViewById(R.id.goalsDisplay);
        goalDisplay.setText("Goals: " + goalsCompleted+"/"+goalsTotal);
        //repositioning eye
        if(save_loaded && locationsMovedTo_data!= null){
            returnEyeToSavedLocation();
        }

        //gameBoard Logic for moving
        board = findViewById(R.id.gameBoardDisplay);
        board.setAdapter(new ImageAdapter(this, levelImageList, gameUsing));
        board.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                int y = position / gameWidth;
                int x = position % gameWidth;

                //Gathering Data for previous Location Character Moved from
                int Eye_x = game.getEyeballColumn();
                int Eye_y = game.getEyeballRow();
                Direction Eye_Direction = game.getEyeballDirection();
                int last_position = Eye_y* gameWidth+Eye_x;
                ImageView previousSquareAt = (ImageView) board.getChildAt(last_position);
                Eyeball eyeball = new Eyeball(Eye_x, Eye_y, Eye_Direction);
                //Position Clicked to moved to
                ImageView clickedSquare = (ImageView) board.getChildAt(position);

                if (game.canMoveTo(x, y)) {
                    playerHasMoved=true;
                    moveCount++;

                    game.moveTo(x, y);
                    if(locationsMovedTo.size()==0){
                        locationsMovedTo.add(eyeball);
                    }
                    Eyeball newEyePosition = new Eyeball(game.getEyeballColumn(), game.getEyeballRow(), game.getEyeballDirection());
                    locationsMovedTo.add(newEyePosition);
                    if (game.getGoalCount() == 0) {
                        playAudio("Win");
                        allGoalsCompleted = true;
//                        Toast.makeText(MainActivity.this, "Level Completed", Toast.LENGTH_SHORT).show();
                        toggleChronometerOn(null);
                    } else {
                        playAudio("Move");
                        //if there was a goal at previous location in a multiGoaled level
                        if(OriginalGame.hasGoalAt(Eye_x,Eye_y)){
                            previousSquareAt.setBackgroundResource(R.drawable._0x);
                            previousSquareAt.setImageResource(R.drawable._0x);
                        }
                    }

                    Direction direction = game.getEyeballDirection();
                    if (direction == Direction.UP) {
                        clickedSquare.setBackgroundResource(R.drawable.eye_facing_up);
                    } else if (direction == Direction.DOWN) {
                        clickedSquare.setBackgroundResource(R.drawable.eye_facing_down);
                    } else if (direction == Direction.LEFT) {
                        clickedSquare.setBackgroundResource(R.drawable.eye_facing_left);
                    } else if (direction == Direction.RIGHT) {
                        clickedSquare.setBackgroundResource(R.drawable.eye_facing_right);
                    }

                    previousSquareAt.setBackgroundResource(R.drawable._0x);
//                    Toast.makeText(MainActivity.this, "Eye x is " +Eye_x+", Eye y is "+Eye_y+", game width "+gameWidth, Toast.LENGTH_SHORT).show();


                } else {
                    playAudio("Incorrect");

                    Message Error_Msg = Message.OK;
                    if(game.MessageIfMovingTo(x,y) != Message.OK){
                        if(game.getShapeAt(x,y) == Shape.BLANK){
                            Error_Msg = Message.INVALID_MOVE;
                        }else{
                            Error_Msg = game.MessageIfMovingTo(x,y);
                        }
                    }else if(game.checkDirectionMessage(x,y) != Message.OK){
                        Error_Msg = game.checkDirectionMessage(x,y);
                    }else if(game.checkMessageForBlankOnPathTo(x,y) != Message.OK){
                        Error_Msg = game.checkMessageForBlankOnPathTo(x,y);
                    }
                    if(Error_Msg !=Message.OK){
                        String Error_Msg_string = Error_Msg.toString();
                        Toast.makeText(MainActivity.this, Error_Msg_string, Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(MainActivity.this, "Invalid Move", Toast.LENGTH_SHORT).show();
                    }

                }

                moveDisplay.setText("Moves: " + moveCount);
                goalsCompleted = game.getCompletedGoalCount();
                TextView goalDisplay = findViewById(R.id.goalsDisplay);
                goalDisplay.setText("Goals: " + goalsCompleted+"/"+goalsTotal);
                gamePlaying = game;
            }
        });
    }

    //undo character actions of moving, goalComplete, etc
    public void undoMove(View view){
        int l = this.locationsMovedTo.size();
        if(playerHasMoved && l>=2){
//            Toast.makeText(MainActivity.this, "l is"+l, Toast.LENGTH_SHORT).show();
            int rowCurrentlyAt = this.locationsMovedTo.get(l-1).getRow();
            int columnCurrentlyAt = this.locationsMovedTo.get(l-1).getColumn();
            int current_position = rowCurrentlyAt* gameWidth+columnCurrentlyAt;
            ImageView SquareAt = (ImageView) board.getChildAt(current_position);
            SquareAt.setBackgroundResource(R.drawable._0x);

            int rowLastAt = this.locationsMovedTo.get(l-2).getRow();
            int columnLastAt = this.locationsMovedTo.get(l-2).getColumn();
            Direction direction = this.locationsMovedTo.get(l-2).getDirection();
            int last_position = rowLastAt* gameWidth+columnLastAt;
            ImageView previousSquareAt = (ImageView) board.getChildAt(last_position);



            if (direction == Direction.UP) {
                previousSquareAt.setBackgroundResource(R.drawable.eye_facing_up);
            } else if (direction == Direction.DOWN) {
                previousSquareAt.setBackgroundResource(R.drawable.eye_facing_down);
            } else if (direction == Direction.LEFT) {
                previousSquareAt.setBackgroundResource(R.drawable.eye_facing_left);
            } else if (direction == Direction.RIGHT) {
                previousSquareAt.setBackgroundResource(R.drawable.eye_facing_right);
            }

            //if there was a goal at previous location in a multiGoaled level
            if(OriginalGame.hasGoalAt(columnLastAt,rowLastAt)){
                previousSquareAt.setImageResource(gameSquaresImagesOriginal[last_position]);
                gamePlaying.restoreGoal(columnLastAt, rowLastAt);
            }

            gamePlaying.setEyeballColumn(columnLastAt);
            gamePlaying.setEyeballRow(rowLastAt);
            gamePlaying.setEyeballDirection(direction);
            this.locationsMovedTo.remove(l-1);
            --moveCount;
            TextView moveDisplay = findViewById(R.id.movesDisplay);
            moveDisplay.setText("Moves: " + moveCount);
        }else{
            playerHasMoved = false;
            Toast.makeText(MainActivity.this, "You can't move back any more", Toast.LENGTH_SHORT).show();
        }

    }

    private void returnEyeToSavedLocation(){
        Toast.makeText(MainActivity.this, "eye to last saved location", Toast.LENGTH_SHORT).show();
        locationsMovedTo = locationsMovedTo_data;
        int l = this.locationsMovedTo.size();
        int rowCurrentlyAt = this.locationsMovedTo.get(l-1).getRow();
        int columnCurrentlyAt = this.locationsMovedTo.get(l-1).getColumn();
        Direction direction = this.locationsMovedTo.get(l-1).getDirection();
        int current_position = rowCurrentlyAt* gameWidth+columnCurrentlyAt;
        ImageView SquareAt = (ImageView) board.getChildAt(current_position);
        if (direction == Direction.UP) {
            SquareAt.setBackgroundResource(R.drawable.eye_facing_up);
        } else if (direction == Direction.DOWN) {
            SquareAt.setBackgroundResource(R.drawable.eye_facing_down);
        } else if (direction == Direction.LEFT) {
            SquareAt.setBackgroundResource(R.drawable.eye_facing_left);
        } else if (direction == Direction.RIGHT) {
            SquareAt.setBackgroundResource(R.drawable.eye_facing_right);
        }
        gamePlaying.setEyeballColumn(columnCurrentlyAt);
        gamePlaying.setEyeballRow(rowCurrentlyAt);
        gamePlaying.setEyeballDirection(direction);
    }


    /////////////////////////////[ Dialog on Pause ]////////////////////////////////////
    private void openDialog() {
//        gameSaving.add(gamePlaying);
        PauseDialog pauseDialog = new PauseDialog();
        pauseDialog.show(getSupportFragmentManager(), "pause dialog");
    }

    ///////////////////////////[ Time, Audio ]/////////////////////////////////////////
    public void toggleChronometerOn(View view) {
        if (!running) {
            //start
            if(save_loaded){
                chronometer.setBase(timer_data - timerPauseOffSet_data);
            }else{
                chronometer.setBase(SystemClock.elapsedRealtime() - pauseOffSet);
            }

            chronometer.start();
            ImageButton btn = findViewById(R.id.pauseButton);
            btn.setImageResource(R.drawable.pause_black_24dp);
            running = true;
        } else if (running) {
            //pause
            chronometer.stop();
            if(save_loaded) {
                timerPauseOffSet_data = SystemClock.elapsedRealtime() - chronometer.getBase();
            }else{
                pauseOffSet = SystemClock.elapsedRealtime() - chronometer.getBase();
            }
            running = false;
            ImageButton btn = findViewById(R.id.pauseButton);
            btn.setImageResource(R.drawable.play_arrow_black_24dp);
            if (allGoalsCompleted) {
                double endTime = pauseOffSet;
                endTime = endTime/100000;
                endTime = Math.floor(endTime*100.0)/100.0;
                timeCompletedLevel = String.valueOf(endTime);
                VictoryDialog victoryDialog = new VictoryDialog();
                victoryDialog.show(getSupportFragmentManager(), "victory dialog");
                if(save_loaded){
                    savedGameWon = true;
                }
            } else {
                openDialog();
            }
        }
    }

    public String timeCompletedLevelIn(View view) {
        return timeCompletedLevel;
    }


    public void toggleAudioOn(View view) {
        ImageButton btn = findViewById(R.id.volumeButton);
        if (audioOn) {
            audioOn = false;
            btn.setImageResource(R.drawable.volume_off_black_24dp);
        } else {
            audioOn = true;
            btn.setImageResource(R.drawable.volume_up_black_24dp);

        }
    }

    private void playAudio(String sound) {
        final MediaPlayer moveAudio = MediaPlayer.create(MainActivity.this, R.raw.move);
        final MediaPlayer winAudio = MediaPlayer.create(MainActivity.this, R.raw.win);
        final MediaPlayer moveIncorrectAudio = MediaPlayer.create(MainActivity.this, R.raw.incorrect);
        if (audioOn) {
            if (sound.equals("Move")) {
                moveAudio.start();
            } else if (sound.equals("Incorrect")) {
                moveIncorrectAudio.start();
            } else if (sound.equals("Win")) {
                winAudio.start();
            }
        }
    }

    /////////////////////////[ Save, Load, Clear Saved Data]//////////////////////////////////////
    public void saveData() {
//
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        editor.putBoolean("saveStored", true);
        editor.putInt("moveCount_Data", moveCount);
//        editor.putInt("goalsCompleted_Data", gamePlaying.getCompletedGoalCount());
//        editor.putInt("goalsTotal_Data", gamePlaying.getGoalCount());
        editor.putLong("timer_data", chronometer.getBase());
        editor.putLong("timerPauseOffSet_data", pauseOffSet);
        editor.putInt("levelNum_data",levelNum);
//        String gameJson = gson.toJson(gameSaving);
//        editor.putString("gameSaving", gameJson);
        String gameImageJson = gson.toJson(currentLevelImageCollection);
        editor.putString("gameImagesContainer", gameImageJson);
        String gameMovesJson = gson.toJson(locationsMovedTo);
        editor.putString("locationsMovedTo", gameMovesJson);



        editor.apply();
        Toast.makeText(MainActivity.this, "Level data has been saved", Toast.LENGTH_SHORT).show();
//        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//        Gson gson = new Gson();
//        String json = gson.toJson(gamePlaying);
//        editor.putString("gamePlaying", json);
//        editor.apply();
    }

    public void loadData(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        Gson gson = new Gson();
        savedGameToLoad = sharedPreferences.getBoolean("saveStored", false);
        moveCount_data = sharedPreferences.getInt("moveCount_Data", 0);
        timer_data = sharedPreferences.getLong("timer_data", SystemClock.elapsedRealtime());
        timerPauseOffSet_data = sharedPreferences.getLong("timerPauseOffSet_data", pauseOffSet);
        levelNum = sharedPreferences.getInt("levelNum_data", 1);
//        String json_game = sharedPreferences.getString("gamePlaying", null);
//        Type gameType = new TypeToken<ArrayList<Game>>(){}.getType();
//        if(gson.fromJson(json_game, gameType)){
//            gameSaving = gson.fromJson(json_game, gameType);
//            gamePlaying = gameSaving.get(0);
//        }
//        gamePlaying = gson.fromJson(json_game, gameType);
//        gamePlaying = gson.fromJson(json_game, Game.class);
        String json_gameImages = sharedPreferences.getString("gameImagesContainer", null);
        Type gameImagesType = new TypeToken<ArrayList<int[]>>(){}.getType();
        if(gson.fromJson(json_gameImages, gameImagesType) != null){
            currentLevelImageCollection_data = gson.fromJson(json_gameImages, gameImagesType);
        }
        String json_gameMoves = sharedPreferences.getString("locationsMovedTo", null);
        Type gameMovesList_type = new TypeToken<ArrayList<Eyeball>>(){}.getType();

        if(gson.fromJson(json_gameMoves, gameMovesList_type) != null){
            locationsMovedTo_data = gson.fromJson(json_gameMoves, gameMovesList_type);
        }
//        Toast.makeText(MainActivity.this, "a load has been called", Toast.LENGTH_SHORT).show();
//        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
//        Gson gson = new Gson();
//        String json = sharedPreferences.getString("gamePlaying", null);
//        Type type = new TypeToken<Game>(){}.getType();
//        gamePlaying = gson.fromJson(json, type);
//
//        if(gamePlaying == null){
//            gamePlaying = new Game();
//        }

    }

    public void outputSavedGameData(View view){
        save_loaded = true;
        loadData();
        displayGame(null);
        Toast.makeText(MainActivity.this, "successfully loaded saved game, last made moves are "+moveCount_data, Toast.LENGTH_SHORT).show();
    }

    public void clearSavedData(View view){
//        this.getSharedPreferences(SHARED_PREFS, MODE_PRIVATE).edit().clear().commit();
        this.getSharedPreferences(SHARED_PREFS, MODE_PRIVATE).edit().clear().apply();
        confirmSaveToLoad(null);
        savedGameToLoad = false;
        save_loaded = false;
        Toast.makeText(MainActivity.this, "previous save has been cleared", Toast.LENGTH_SHORT).show();

    }
}