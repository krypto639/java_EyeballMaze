package com.example.a3_java_v3.model.gameComponents;

//import com.sun.tools.javac.util.List;

import com.example.a3_java_v3.model.Interfaces.IEyeballHolder;
import com.example.a3_java_v3.model.Interfaces.IGoalHolder;
import com.example.a3_java_v3.model.Interfaces.ILevelHolder;
import com.example.a3_java_v3.model.Interfaces.ISquareHolder;
import com.example.a3_java_v3.model.gameEnums.Color;
import com.example.a3_java_v3.model.gameEnums.Direction;
import com.example.a3_java_v3.model.gameEnums.Message;
import com.example.a3_java_v3.model.gameEnums.Shape;

import java.util.ArrayList;
import java.util.List;

public class Game implements IEyeballHolder, IGoalHolder, ILevelHolder, ISquareHolder {
    protected List<Level> allMyLevels = new ArrayList<Level>();
    protected Level currentLevel;

    public void addLevel(int width, int height) {
        Level level = new Level(width, height);
        this.allMyLevels.add(level);
        this.currentLevel = level;

    }

    //	LEVEL SETUP
    @Override
    public int getLevelWidth() {
        return this.currentLevel.width;

    }

    @Override
    public int getLevelHeight() {
        return this.currentLevel.height;
    }

    @Override
    public void setLevel(int levelNumber) {
        int levelCount = getLevelCount();
        if (levelNumber > levelCount) {
            throw new IllegalArgumentException();
        } else {
            this.currentLevel = this.allMyLevels.get(levelNumber);
        }

    }

    @Override
    public int getLevelCount() {
        int levelCount = this.allMyLevels.size();
        return levelCount;
    }

    //	SHAPES SETTUP AND CONFIRMATION OF CORRECT DETAILS
    @Override
    public void addSquare(Square square, int column, int row) {
        this.currentLevel.addSquare(square, column, row);
    }

    @Override
    public Color getColorAt(int column, int row) {
        return this.currentLevel.getColorAt(column, row);
    }

    @Override
    public Shape getShapeAt(int column, int row) {
        return this.currentLevel.getShapeAt(column, row);
    }

    //	GOALS SETUP AND VALIDATION
    @Override
    //height is always first, width
    public void addGoal(int column, int row) {
//		System.out.println("game.addGoal has been triggered");
        this.currentLevel.addGoal(column, row);

    }

    @Override
    public int getGoalCount() {
        return this.currentLevel.getGoalCount();
    }

    @Override
    public boolean hasGoalAt(int targetColumn, int targetRow) {
        return this.currentLevel.hasGoalAt(targetColumn, targetRow);
    }

    @Override
    public int getCompletedGoalCount() {
        return this.currentLevel.getCompletedGoalCount();
    }

    //	EYEBALL SETUP AND METHODS
    public void addEyeball(int column, int row, Direction direction) {
        this.currentLevel.addEyeball(column, row, direction);
    }

    @Override
    public int getEyeballRow() {
        return this.currentLevel.getEyeballRow();
    }

    @Override
    public int getEyeballColumn() {
        return this.currentLevel.getEyeballColumn();
    }

    @Override
    public Direction getEyeballDirection() {
        return this.currentLevel.getEyeballDirection();
    }

    //Undo android studio functions
    public int setEyeballRow(int row){
        return this.currentLevel.setEyeballRow(row);
    }

    public int setEyeballColumn(int column){
        return this.currentLevel.setEyeballColumn(column);
    }

    public Direction setEyeballDirection(Direction direction){
        return this.currentLevel.setEyeballDirection(direction);
    }

    //	MOVEMENT METHODS
    public boolean canMoveTo(int column, int row) {
        return this.currentLevel.canMoveTo(column, row);
        //return false;
    }

    public boolean hasBlankFreePathTo(int column, int row) {
        return this.currentLevel.hasBlankFreePathTo(column, row);
    }

    public void moveTo(int column, int row) {
        this.currentLevel.moveTo(column, row);
    }

    public Message checkMessageForBlankOnPathTo(int column, int row) {
        return this.currentLevel.checkMessageForBlankOnPathTo(column, row);
    }

    public Message checkDirectionMessage(int column, int row) {
        return this.currentLevel.checkDirectionMessage(column, row);
    }

    public boolean isDirectionOK(int column, int row) {
        return this.currentLevel.isDirectionOK(column, row);
    }

    public Message MessageIfMovingTo(int column, int row) {
        return this.currentLevel.MessageIfMovingTo(column, row);
    }


    public void restoreGoal(int columnLastAt, int rowLastAt) {
        this.currentLevel.restoreGoal(columnLastAt, rowLastAt);
    }
}
