package com.example.a3_java_v3.model.gameComponents;

import com.example.a3_java_v3.model.gameEnums.Color;
import com.example.a3_java_v3.model.gameEnums.Shape;

public class PlayableSquare extends Square {
    public PlayableSquare(Color color, Shape shape) {
        super(color, shape);
    }
}
