package com.example.a3_java_v3;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatDialogFragment;

public class VictoryDialog extends AppCompatDialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        String[] dialog_options = getActivity().getResources().getStringArray(R.array.pause_dialog_options);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Level Completed")
                .setMessage("You have completed the level in " + ((MainActivity) getActivity()).timeCompletedLevelIn(null))
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ((MainActivity) getActivity()).setContentView(R.layout.activity_main);
                        ((MainActivity) getActivity()).confirmSaveToLoad(null);

                    }
                });

        return builder.create();

    }
}
