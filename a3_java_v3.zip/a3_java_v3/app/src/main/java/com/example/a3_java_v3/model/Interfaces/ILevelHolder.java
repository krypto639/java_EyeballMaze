package com.example.a3_java_v3.model.Interfaces;

public interface ILevelHolder {
    public void addLevel(int width, int height);

    public int getLevelWidth();

    public int getLevelHeight();

    public void setLevel(int levelNumber);

    public int getLevelCount();
}
