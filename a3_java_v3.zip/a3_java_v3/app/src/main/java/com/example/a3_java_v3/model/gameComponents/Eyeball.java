package com.example.a3_java_v3.model.gameComponents;

import com.example.a3_java_v3.model.gameEnums.Direction;

public class Eyeball {
    protected int row;
    protected int column;
    protected Direction direction;

    public Eyeball(int column, int row, Direction direction) {
        this.column = column;
        this.row = row;
        this.direction = direction;
    }

    public int getRow() {
        return row;
    }

    public int getColumn() {
        return column;
    }

    public Direction getDirection() {
        return direction;
    }


}
