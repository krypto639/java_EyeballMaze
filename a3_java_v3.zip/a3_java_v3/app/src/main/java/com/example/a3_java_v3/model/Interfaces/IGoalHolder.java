package com.example.a3_java_v3.model.Interfaces;

public interface IGoalHolder {
    public void addGoal(int column, int row);

    public int getGoalCount();

    public boolean hasGoalAt(int targetColumn, int targetRow);

    public int getCompletedGoalCount();

    public void restoreGoal(int columnLastAt, int rowLastAt);
}
