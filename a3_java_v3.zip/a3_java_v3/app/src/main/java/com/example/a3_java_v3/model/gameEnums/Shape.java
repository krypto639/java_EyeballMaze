package com.example.a3_java_v3.model.gameEnums;

public enum Shape {
    DIAMOND, CROSS, STAR, FLOWER, BLANK, LIGHTNING
}
